//utilizei I.A para realizar algumas coisas, principalmente pra erros. Mas também para coisas em que eu não sabia como fazer
import java.util.PriorityQueue;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 04614584039
 */
public class trabIndividual {

    public static class Processo implements Comparable<Processo> {
        private int id;
        private int prioridade;
        private String descricao;

        public Processo(int id, int prioridade, String descricao) {
            this.id = id;
            this.prioridade = prioridade;
            this.descricao = descricao;
        }

        public int getId() {
            return id;
        }

        public int getPrioridade() {
            return prioridade;
        }

        public String getDescricao() {
            return descricao;
        }

        @Override
        public String toString() {
            return "ID: " + id + ", Prioridade: " + prioridade + ", Descrição: " + descricao;
        }

        @Override
        public int compareTo(Processo outro) {
            // A comparação é feita pela prioridade (menor valor é mais prioritário)
            return Integer.compare(this.prioridade, outro.prioridade);
        }
    }

    public static class FilaDePrioridade { //gerenciador da fila de processo
        private PriorityQueue<Processo> fila; //pra garantir que os processos sejam sempre ordenados por prioridade 
        private int contadorId; // gerar ids únicos

        public FilaDePrioridade() {
            fila = new PriorityQueue<>();
            contadorId = 1; // começa com id 1 e segue sucessivamente
        }

        public void adicionarProcesso(int prioridade, String descricao) {
            int id = contadorId++; // Gerar o id automaticamente
            
            fila.add(new Processo(id, prioridade, descricao)); // pra adicionar o novo processo a fila
            System.out.println("Processo com ID " + id + " adicionado com sucesso");
        }

        public void exibirFila() {
            if (fila.isEmpty()) {
                System.out.println("Fila vazia");
                return;
            }
            System.out.println("Fila Atual:");
            for (Processo processo : fila) {
                System.out.println(processo);
            }
        }

        public void executarProcesso() {
            if (fila.isEmpty()) {
                System.out.println("Fila vazia");
                return;
            }
            Processo processo = fila.poll();  // limpa e retorna o processo com a maior prioridade
            System.out.println("Executando: " + processo);
        }

        public void simularExecucaoCompleta() {
            if (fila.isEmpty()) {
                System.out.println("Fila vazia");
                return;
            }
            while (!fila.isEmpty()) {
                executarProcesso();
            }
            System.out.println("Fila vazia");
        }
    }

    // metodo principal para interação com o usuario
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FilaDePrioridade fila = new FilaDePrioridade();
        
        while (true) {
            System.out.println("\nEscolha uma opção:");
            System.out.println("1. Adicionar Processo");
            System.out.println("2. Exibir Fila de Processos");
            System.out.println("3. Executar Processo");
            System.out.println("4. Simular Execução Completa");
            System.out.println("5. Sair");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Informe a prioridade (0 a 15): ");
                    int prioridade = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Informe a descrição do processo: ");
                    String descricao = scanner.nextLine();
                    fila.adicionarProcesso(prioridade, descricao);
                    break;
                case 2:
                    fila.exibirFila();
                    break;
                case 3:
                    fila.executarProcesso();
                    break;
                case 4:
                    fila.simularExecucaoCompleta();
                    break;
                case 5:
                    scanner.close();
                    return;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
}


